# Friend AI — Android personal assistant (Kotlin · Compose · Gemini)

Developer: N4YEMx

## 0. Quick start (personal use)
Put `GEMINI_API_KEY=...` in `local.properties`, leave `BACKEND_URL` empty, build. Never share that APK.

## 1. Deploy the secure proxy (for sharing/publishing) (keeps the Gemini key out of the APK)
Needs a free Cloudflare account and Node.js.
```
cd backend
npx wrangler login
npx wrangler secret put GEMINI_API_KEY     # paste your key from aistudio.google.com
npx wrangler secret put APP_TOKEN          # any long random string
npx wrangler deploy                        # prints https://friend-ai-proxy.<you>.workers.dev
```

## 2. Point the app at it
Copy `local.properties.example` to `local.properties` (next to `settings.gradle.kts`) and fill in
`BACKEND_URL` and the same `APP_TOKEN`. Android Studio adds `sdk.dir` automatically.

## 3. Build
Open the `FriendAI` folder in Android Studio (Koala or newer, JDK 17), let Gradle sync, press Run.
(`gradle-wrapper.jar` is not bundled — Android Studio regenerates the wrapper; or run `gradle wrapper`.)

## 4. Permissions (in-app: Settings tab)
Microphone, Contacts, Phone, Notifications, and the Accessibility service.
On sideloaded builds, Android 13+ may grey out the accessibility switch:
Settings → Apps → Friend AI → ⋮ → Allow restricted settings.

## Safety design
- Gemini can only request the functions declared in `ai/Tools.kt`; nothing else executes.
- Calls always show a confirmation dialog (voice "yes"/"হ্যাঁ" also works). Taps on words like
  send/pay/buy/delete/confirm also ask first.
- Password fields are never read or typed into.
- Proxy checks `APP_TOKEN`; rotate it if the APK is shared. For stronger protection add Firebase App Check.

## Known limits
- Bangla recognition/voice needs the Google speech + a Bangla TTS voice installed on the phone.
- Banking/secure apps block accessibility reads. TikTok/YouTube UI changes can break "tap by text".
- Reminders use inexact alarms (can fire a few minutes late in Doze).
