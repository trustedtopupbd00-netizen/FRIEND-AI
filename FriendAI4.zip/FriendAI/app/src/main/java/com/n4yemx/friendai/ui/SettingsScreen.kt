package com.n4yemx.friendai.ui

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.n4yemx.friendai.BuildConfig
import com.n4yemx.friendai.MainViewModel
import com.n4yemx.friendai.service.FriendAccessibilityService

@Composable
private fun resumeTick(): Int {
    var t by remember { mutableIntStateOf(0) }
    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner) {
        val o = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_RESUME) t++ }
        owner.lifecycle.addObserver(o)
        onDispose { owner.lifecycle.removeObserver(o) }
    }
    return t
}

private fun has(ctx: Context, p: String) = ContextCompat.checkSelfPermission(ctx, p) == PackageManager.PERMISSION_GRANTED

@Composable
fun SettingsScreen(vm: MainViewModel) {
    val ctx = LocalContext.current
    var tick by remember { mutableIntStateOf(0) }
    val resume = resumeTick()
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { tick++ }
    val lang by vm.language.collectAsStateWithLifecycle()
    val speakTyped by vm.speakTyped.collectAsStateWithLifecycle()
    val hands by vm.handsFree.collectAsStateWithLifecycle()

    Column(Modifier.fillMaxSize().background(Navy).statusBarsPadding().verticalScroll(rememberScrollState()).padding(16.dp)) {
        Text("Settings", style = MaterialTheme.typography.headlineSmall.copy(brush = NeonBrush, fontWeight = FontWeight.Bold))
        Spacer(Modifier.height(16.dp))

        Section("Permissions")
        key(tick, resume) {
            PermRow("Microphone", "Voice commands", has(ctx, Manifest.permission.RECORD_AUDIO)) { launcher.launch(Manifest.permission.RECORD_AUDIO) }
            PermRow("Contacts", "Find who to call", has(ctx, Manifest.permission.READ_CONTACTS)) { launcher.launch(Manifest.permission.READ_CONTACTS) }
            PermRow("Phone", "Place calls after you confirm", has(ctx, Manifest.permission.CALL_PHONE)) { launcher.launch(Manifest.permission.CALL_PHONE) }
            if (Build.VERSION.SDK_INT >= 33)
                PermRow("Notifications", "Reminder alerts", has(ctx, Manifest.permission.POST_NOTIFICATIONS)) { launcher.launch(Manifest.permission.POST_NOTIFICATIONS) }
            PermRow("Accessibility service", "Tap, scroll, type, back/home", FriendAccessibilityService.isEnabled(ctx)) {
                ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }
        }
        Text(
            "Sideloaded app and the Accessibility switch is greyed out? Open Android Settings > Apps > Friend AI > ⋮ menu > \"Allow restricted settings\", then try again.",
            color = Color(0xFF9AA6D6), fontSize = 12.sp, modifier = Modifier.padding(vertical = 8.dp)
        )

        Section("Voice")
        SwitchRow("Bangla speech recognition", "Off = English", lang.startsWith("bn")) { vm.setLanguage(if (it) "bn-BD" else "en-US") }
        SwitchRow("Continuous conversation", "Keep listening after each reply", hands) { vm.setHandsFree(it) }
        SwitchRow("Speak replies to typed messages", "Replies to voice are always spoken", speakTyped) { vm.setSpeakTyped(it) }

        Section("Backend")
        Text(
            when {
                BuildConfig.BACKEND_URL.isNotBlank() -> "Secure proxy: ${BuildConfig.BACKEND_URL}"
                BuildConfig.GEMINI_API_KEY.isNotBlank() -> "Personal mode: direct Gemini key (don't share this APK)"
                else -> "No key/proxy set — edit local.properties and rebuild."
            },
            color = if (BuildConfig.BACKEND_URL.isNotBlank() || BuildConfig.GEMINI_API_KEY.isNotBlank()) Cyan else MaterialTheme.colorScheme.error, fontSize = 13.sp
        )

        Section("Data")
        OutlinedButton(onClick = { vm.clearChat() }) { Text("Clear conversation history") }
        Spacer(Modifier.height(24.dp))
        Text("Friend AI 1.0 · by N4YEMx", color = Color(0xFF9AA6D6), fontSize = 12.sp)
    }
}

@Composable private fun Section(t: String) =
    Text(t, color = Cyan, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 12.dp, bottom = 6.dp))

@Composable
private fun PermRow(title: String, desc: String, granted: Boolean, onGrant: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 3.dp).clip(RoundedCornerShape(14.dp)).background(PanelHi).padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) { Text(title, fontWeight = FontWeight.SemiBold); Text(desc, color = Color(0xFF9AA6D6), fontSize = 12.sp) }
        if (granted) Text("✓ On", color = Cyan) else Button(onClick = onGrant) { Text("Enable") }
    }
}

@Composable
private fun SwitchRow(title: String, desc: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 3.dp).clip(RoundedCornerShape(14.dp)).background(PanelHi).padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) { Text(title, fontWeight = FontWeight.SemiBold); Text(desc, color = Color(0xFF9AA6D6), fontSize = 12.sp) }
        Switch(checked = checked, onCheckedChange = onChange)
    }
}
