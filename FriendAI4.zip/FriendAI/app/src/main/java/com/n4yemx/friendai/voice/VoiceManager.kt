package com.n4yemx.friendai.voice

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import kotlinx.coroutines.flow.MutableStateFlow
import java.util.Locale

enum class VoiceState { IDLE, LISTENING, SPEAKING }

/** Speech-to-text (Bangla / English) + text-to-speech, with state and mic level for the animations. */
class VoiceManager(private val app: Context) {
    val state = MutableStateFlow(VoiceState.IDLE)
    val partial = MutableStateFlow("")
    val level = MutableStateFlow(0f)

    var recognitionTag = "bn-BD"
    var onFinal: (String) -> Unit = {}
    var onError: (Int) -> Unit = {}
    var onSpeakDone: () -> Unit = {}

    private val main = Handler(Looper.getMainLooper())
    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false

    init {
        tts = TextToSpeech(app) { status ->
            ttsReady = status == TextToSpeech.SUCCESS
            tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {}
                override fun onDone(utteranceId: String?) { finishSpeaking() }
                @Deprecated("Deprecated in Java") override fun onError(utteranceId: String?) { finishSpeaking() }
            })
        }
    }

    private fun finishSpeaking() = main.post {
        if (state.value == VoiceState.SPEAKING) {
            state.value = VoiceState.IDLE
            onSpeakDone()
        }
    }

    fun startListening() {
        main.post {
            stopSpeakingInternal()
            if (!SpeechRecognizer.isRecognitionAvailable(app)) { onError(-1); return@post }
            recognizer?.destroy()
            recognizer = SpeechRecognizer.createSpeechRecognizer(app).also { r ->
                r.setRecognitionListener(object : RecognitionListener {
                    override fun onReadyForSpeech(params: Bundle?) {}
                    override fun onBeginningOfSpeech() {}
                    override fun onRmsChanged(rmsdB: Float) { level.value = ((rmsdB + 2f) / 12f).coerceIn(0f, 1f) }
                    override fun onBufferReceived(buffer: ByteArray?) {}
                    override fun onEndOfSpeech() {}
                    override fun onEvent(eventType: Int, params: Bundle?) {}
                    override fun onPartialResults(partialResults: Bundle?) {
                        partial.value = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                    }
                    override fun onResults(results: Bundle?) {
                        val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                        resetListening()
                        if (text.isBlank()) onError(SpeechRecognizer.ERROR_NO_MATCH) else onFinal(text)
                    }
                    override fun onError(error: Int) { resetListening(); this@VoiceManager.onError(error) }
                })
            }
            val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, recognitionTag)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, recognitionTag)
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            }
            partial.value = ""
            state.value = VoiceState.LISTENING
            recognizer?.startListening(i)
        }
    }

    private fun resetListening() { level.value = 0f; partial.value = ""; if (state.value == VoiceState.LISTENING) state.value = VoiceState.IDLE }

    fun stopListening() { main.post { recognizer?.cancel(); resetListening() } }

    fun speak(text: String) {
        main.post {
            if (!ttsReady) return@post
            val clean = text.replace(Regex("[*_`#>]"), "").take(3000)
            val isBangla = clean.any { it in '\u0980'..'\u09FF' }
            val locale = if (isBangla) Locale("bn", "BD") else Locale.US
            val r = tts?.setLanguage(locale)
            if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) tts?.setLanguage(Locale.getDefault())
            state.value = VoiceState.SPEAKING
            tts?.speak(clean, TextToSpeech.QUEUE_FLUSH, null, "friend_ai_utt")
        }
    }

    private fun stopSpeakingInternal() {
        tts?.stop()
        if (state.value == VoiceState.SPEAKING) state.value = VoiceState.IDLE
    }

    fun stopSpeaking() { main.post { stopSpeakingInternal() } }

    fun release() {
        recognizer?.destroy(); recognizer = null
        tts?.stop(); tts?.shutdown(); tts = null
    }
}
