package com.n4yemx.friendai.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.n4yemx.friendai.MainViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun LibraryScreen(vm: MainViewModel) {
    var tab by remember { mutableIntStateOf(0) }
    Column(Modifier.fillMaxSize().background(Navy).statusBarsPadding()) {
        Text("My Space", style = MaterialTheme.typography.headlineSmall.copy(brush = NeonBrush, fontWeight = FontWeight.Bold), modifier = Modifier.padding(16.dp))
        TabRow(selectedTabIndex = tab, containerColor = Color.Transparent, contentColor = Cyan) {
            listOf("Notes", "To-do", "Reminders").forEachIndexed { i, t ->
                Tab(selected = tab == i, onClick = { tab = i }, text = { Text(t) })
            }
        }
        when (tab) { 0 -> NotesTab(vm); 1 -> TodoTab(vm); else -> ReminderTab(vm) }
    }
}

@Composable
private fun ItemCard(content: @Composable RowScope.() -> Unit) = Row(
    Modifier.fillMaxWidth().padding(vertical = 4.dp).clip(RoundedCornerShape(14.dp)).background(PanelHi).padding(12.dp),
    verticalAlignment = Alignment.CenterVertically, content = content
)

private val fieldColors @Composable get() = OutlinedTextFieldDefaults.colors(focusedBorderColor = Cyan, unfocusedBorderColor = PanelHi)

@Composable
private fun NotesTab(vm: MainViewModel) {
    val notes by vm.notes.collectAsStateWithLifecycle()
    var title by remember { mutableStateOf("") }
    var body by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        OutlinedTextField(title, { title = it }, label = { Text("Title (optional)") }, singleLine = true, modifier = Modifier.fillMaxWidth(), colors = fieldColors)
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(body, { body = it }, label = { Text("Note") }, modifier = Modifier.fillMaxWidth(), colors = fieldColors)
        Button(onClick = { if (body.isNotBlank()) { vm.addNote(title, body); title = ""; body = "" } }, modifier = Modifier.align(Alignment.End).padding(top = 8.dp)) { Text("Save") }
        LazyColumn(Modifier.weight(1f)) {
            items(notes, key = { it.id }) { n ->
                ItemCard {
                    Column(Modifier.weight(1f)) { Text(n.title, fontWeight = FontWeight.Bold, color = Cyan); Text(n.body) }
                    IconButton(onClick = { vm.deleteNote(n.id) }) { Icon(Icons.Rounded.Delete, "Delete") }
                }
            }
        }
    }
}

@Composable
private fun TodoTab(vm: MainViewModel) {
    val todos by vm.todos.collectAsStateWithLifecycle()
    var text by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(text, { text = it }, label = { Text("New task") }, singleLine = true, modifier = Modifier.weight(1f), colors = fieldColors)
            Button(onClick = { if (text.isNotBlank()) { vm.addTodo(text); text = "" } }, modifier = Modifier.padding(start = 8.dp)) { Text("Add") }
        }
        Spacer(Modifier.height(8.dp))
        LazyColumn(Modifier.weight(1f)) {
            items(todos, key = { it.id }) { t ->
                ItemCard {
                    Checkbox(checked = t.done, onCheckedChange = { vm.toggleTodo(t) })
                    Text(t.text, Modifier.weight(1f), textDecoration = if (t.done) TextDecoration.LineThrough else null,
                        color = if (t.done) Color(0xFF9AA6D6) else Color.White)
                    IconButton(onClick = { vm.deleteTodo(t.id) }) { Icon(Icons.Rounded.Delete, "Delete") }
                }
            }
        }
    }
}

@Composable
private fun ReminderTab(vm: MainViewModel) {
    val items by vm.reminders.collectAsStateWithLifecycle()
    var text by remember { mutableStateOf("") }
    var mins by remember { mutableStateOf("10") }
    val fmt = remember { SimpleDateFormat("EEE d MMM, h:mm a", Locale.getDefault()) }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        OutlinedTextField(text, { text = it }, label = { Text("Remind me to…") }, singleLine = true, modifier = Modifier.fillMaxWidth(), colors = fieldColors)
        Row(Modifier.padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(mins, { mins = it.filter(Char::isDigit) }, label = { Text("In minutes") }, singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.width(140.dp), colors = fieldColors)
            Spacer(Modifier.weight(1f))
            Button(onClick = { val m = mins.toLongOrNull(); if (text.isNotBlank() && m != null && m > 0) { vm.addReminder(text, m); text = "" } }) { Text("Set") }
        }
        Spacer(Modifier.height(8.dp))
        LazyColumn(Modifier.weight(1f)) {
            items(items, key = { it.id }) { r ->
                ItemCard {
                    Column(Modifier.weight(1f)) {
                        Text(r.text, fontWeight = FontWeight.Bold)
                        Text(fmt.format(Date(r.triggerAt)) + if (r.fired) "  ✓ done" else "", color = Cyan)
                    }
                    IconButton(onClick = { vm.deleteReminder(r) }) { Icon(Icons.Rounded.Delete, "Delete") }
                }
            }
        }
    }
}
