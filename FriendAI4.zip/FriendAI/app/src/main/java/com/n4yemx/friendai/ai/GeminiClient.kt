package com.n4yemx.friendai.ai

import com.n4yemx.friendai.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * Talks to YOUR backend proxy (backend/worker.js), which holds the Gemini API key.
 * The request/response bodies are plain Gemini generateContent JSON.
 */
class GeminiClient {
    private val http = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .build()

    suspend fun generate(contents: JSONArray, systemPrompt: String): JSONObject = withContext(Dispatchers.IO) {
        val direct = BuildConfig.BACKEND_URL.isBlank() && BuildConfig.GEMINI_API_KEY.isNotBlank()
        check(direct || BuildConfig.BACKEND_URL.isNotBlank()) {
            "Add GEMINI_API_KEY (personal use) or BACKEND_URL (secure proxy) to local.properties."
        }
        val body = JSONObject()
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", systemPrompt))))
            .put("contents", contents)
            .put("tools", Tools.declarations)
        val rb = Request.Builder()
        if (direct) {
            // Personal/dev mode: key is compiled into YOUR build. Do not share this APK.
            rb.url("https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent")
                .addHeader("x-goog-api-key", BuildConfig.GEMINI_API_KEY)
        } else {
            rb.url(BuildConfig.BACKEND_URL).addHeader("X-App-Token", BuildConfig.APP_TOKEN)
        }
        val req = rb.post(body.toString().toRequestBody("application/json".toMediaType())).build()
        http.newCall(req).execute().use { r ->
            val s = r.body?.string().orEmpty()
            if (!r.isSuccessful) error("Server error ${r.code}: ${s.take(200)}")
            JSONObject(s)
        }
    }
}
