package com.n4yemx.friendai.service

import android.Manifest
import android.annotation.SuppressLint
import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.n4yemx.friendai.FriendApplication
import com.n4yemx.friendai.MainActivity
import com.n4yemx.friendai.data.AppDatabase
import com.n4yemx.friendai.data.Reminder
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

object ReminderScheduler {
    private fun pi(ctx: Context, id: Long, text: String) = PendingIntent.getBroadcast(
        ctx, id.toInt(),
        Intent(ctx, ReminderReceiver::class.java).putExtra("id", id).putExtra("text", text),
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )

    fun schedule(ctx: Context, r: Reminder) {
        val am = ctx.getSystemService(AlarmManager::class.java)
        am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, r.triggerAt, pi(ctx, r.id, r.text))
    }

    fun cancel(ctx: Context, id: Long) {
        ctx.getSystemService(AlarmManager::class.java).cancel(pi(ctx, id, ""))
    }
}

class ReminderReceiver : BroadcastReceiver() {
    @SuppressLint("MissingPermission")
    override fun onReceive(c: Context, i: Intent) {
        val text = i.getStringExtra("text") ?: "Reminder"
        val id = i.getLongExtra("id", 0L)
        val open = PendingIntent.getActivity(c, 0, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val n = NotificationCompat.Builder(c, FriendApplication.CHANNEL)
            .setSmallIcon(android.R.drawable.ic_popup_reminder)
            .setContentTitle("Friend AI reminder")
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setAutoCancel(true)
            .setContentIntent(open)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .build()
        if (Build.VERSION.SDK_INT < 33 || c.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED) {
            NotificationManagerCompat.from(c).notify(id.toInt(), n)
        }
        val pr = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try { AppDatabase.get(c).reminders().markFired(id) } finally { pr.finish() }
        }
    }
}

/** Alarms are cleared on reboot, so re-arm every pending reminder. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (i.action != Intent.ACTION_BOOT_COMPLETED) return
        val pr = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                AppDatabase.get(c).reminders().pending(System.currentTimeMillis()).forEach { ReminderScheduler.schedule(c, it) }
            } finally { pr.finish() }
        }
    }
}
