package com.n4yemx.friendai.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.consumeWindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ChatBubble
import androidx.compose.material.icons.rounded.EditNote
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import com.n4yemx.friendai.MainViewModel

@Composable
fun AppRoot(vm: MainViewModel) {
    var tab by rememberSaveable { mutableIntStateOf(0) }
    val items = listOf(
        "Chat" to Icons.Rounded.ChatBubble,
        "My Space" to Icons.Rounded.EditNote,
        "Settings" to Icons.Rounded.Settings
    )
    Scaffold(
        containerColor = Navy,
        bottomBar = {
            NavigationBar(containerColor = Panel) {
                items.forEachIndexed { i, (label, icon) ->
                    NavigationBarItem(
                        selected = tab == i, onClick = { tab = i },
                        icon = { Icon(icon, contentDescription = label) },
                        label = { Text(label) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Navy, selectedTextColor = Cyan, indicatorColor = Cyan,
                            unselectedIconColor = androidx.compose.ui.graphics.Color(0xFF9AA6D6),
                            unselectedTextColor = androidx.compose.ui.graphics.Color(0xFF9AA6D6)
                        )
                    )
                }
            }
        }
    ) { pad ->
        Box(Modifier.fillMaxSize().background(Navy).padding(pad).consumeWindowInsets(pad)) {
            when (tab) {
                0 -> ChatScreen(vm)
                1 -> LibraryScreen(vm)
                else -> SettingsScreen(vm)
            }
        }
    }
}
