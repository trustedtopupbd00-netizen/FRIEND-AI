package com.n4yemx.friendai.ai

import org.json.JSONArray
import org.json.JSONObject

/** Gemini function declarations = the only actions the AI is allowed to request. */
object Tools {
    private fun str(desc: String) = JSONObject().put("type", "STRING").put("description", desc)
    private fun num(desc: String) = JSONObject().put("type", "NUMBER").put("description", desc)
    private fun enumStr(desc: String, vararg v: String) =
        JSONObject().put("type", "STRING").put("description", desc).put("enum", JSONArray(v.toList()))

    private fun fn(name: String, desc: String, props: Map<String, JSONObject> = emptyMap(), required: List<String> = emptyList()): JSONObject {
        val o = JSONObject().put("name", name).put("description", desc)
        if (props.isNotEmpty()) {
            o.put(
                "parameters",
                JSONObject().put("type", "OBJECT").put("properties", JSONObject(props)).put("required", JSONArray(required))
            )
        }
        return o
    }

    val declarations: JSONArray = JSONArray().put(
        JSONObject().put(
            "functionDeclarations",
            JSONArray()
                .put(fn("open_app", "Open an installed app by its name (YouTube, TikTok, Chrome, WhatsApp, Camera, Settings...).",
                    mapOf("app_name" to str("App name as the user said it"), "alt_name" to str("Same name in the other script (English/Bangla) or common alias")), listOf("app_name")))
                .put(fn("search_youtube", "Open YouTube and search for videos.",
                    mapOf("query" to str("Search text")), listOf("query")))
                .put(fn("search_tiktok", "Open TikTok and search for videos or creators.",
                    mapOf("query" to str("Search text or creator name"), "kind" to enumStr("What to search", "videos", "creators")), listOf("query")))
                .put(fn("open_settings_page", "Open an Android settings page.",
                    mapOf("page" to enumStr("Which page", "main", "wifi", "bluetooth", "display", "sound", "battery", "apps", "location", "accessibility", "language", "storage", "date")), listOf("page")))
                .put(fn("phone_navigate", "Press a system button or scroll the current screen (needs the accessibility service).",
                    mapOf("action" to enumStr("Action", "back", "home", "recents", "notifications", "quick_settings", "scroll_down", "scroll_up")), listOf("action")))
                .put(fn("tap_text", "Tap a visible button/label on the current screen by its text (accessibility). Use read_screen first if unsure what is visible.",
                    mapOf("text" to str("Visible text or content description of the element")), listOf("text")))
                .put(fn("type_text", "Type text into the currently focused input field (accessibility). Never used for passwords.",
                    mapOf("text" to str("Text to type")), listOf("text")))
                .put(fn("read_screen", "Read the visible text on the current screen so you can decide what to tap or answer what is on screen."))
                .put(fn("call_contact", "Find a saved contact and place a phone call. The app itself asks the user to confirm before dialling.",
                    mapOf("name" to str("Contact name as heard"), "alt_name" to str("Same name transliterated into the other script (Bangla<->English)")), listOf("name")))
                .put(fn("add_note", "Save a note.",
                    mapOf("title" to str("Short title"), "body" to str("Note text")), listOf("body")))
                .put(fn("add_todo", "Add an item to the to-do list.",
                    mapOf("text" to str("Task")), listOf("text")))
                .put(fn("complete_todo", "Mark an open to-do item as done by matching its text.",
                    mapOf("text" to str("Part of the task text")), listOf("text")))
                .put(fn("set_reminder", "Schedule a reminder notification. Give either minutes_from_now or datetime (local time).",
                    mapOf(
                        "text" to str("What to remind about"),
                        "minutes_from_now" to num("Minutes from now"),
                        "datetime" to str("Local date-time formatted yyyy-MM-dd HH:mm")
                    ), listOf("text")))
                .put(fn("list_items", "List saved notes, to-dos or reminders.",
                    mapOf("kind" to enumStr("Which list", "notes", "todos", "reminders")), listOf("kind")))
        )
    )
}
