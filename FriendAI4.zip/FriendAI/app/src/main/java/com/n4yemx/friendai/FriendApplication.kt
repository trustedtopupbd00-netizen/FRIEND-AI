package com.n4yemx.friendai

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager

class FriendApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Reminders", NotificationManager.IMPORTANCE_HIGH)
        )
    }

    companion object { const val CHANNEL = "friend_ai_reminders" }
}
