package com.n4yemx.friendai.ai

import android.Manifest
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.ContactsContract
import android.provider.Settings
import com.n4yemx.friendai.data.*
import com.n4yemx.friendai.service.FriendAccessibilityService
import com.n4yemx.friendai.service.ReminderScheduler
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Asks the human to approve a sensitive action. Implemented by the ViewModel (dialog + voice yes/no). */
interface Confirmer { suspend fun confirm(prompt: String): Boolean }

class ActionEngine(private val ctx: Context, private val db: AppDatabase) {

    private val bn get() = Prefs.language(ctx).startsWith("bn")
    private fun ok(msg: String) = JSONObject().put("ok", true).put("message", msg)
    private fun fail(msg: String) = JSONObject().put("ok", false).put("error", msg)
    private fun noService() = fail("Accessibility service is not enabled. Ask the user to enable Friend AI in Settings > Accessibility.")

    suspend fun execute(name: String, a: JSONObject, c: Confirmer): JSONObject = try {
        when (name) {
            "open_app" -> openApp(a)
            "search_youtube" -> searchYoutube(a.getString("query"))
            "search_tiktok" -> searchTiktok(a.getString("query"), a.optString("kind", "videos"))
            "open_settings_page" -> openSettings(a.optString("page", "main"))
            "phone_navigate" -> navigate(a.getString("action"))
            "tap_text" -> tapText(a.getString("text"), c)
            "type_text" -> typeText(a.getString("text"))
            "read_screen" -> readScreen()
            "call_contact" -> callContact(a, c)
            "add_note" -> addNote(a)
            "add_todo" -> addTodo(a.getString("text"))
            "complete_todo" -> completeTodo(a.getString("text"))
            "set_reminder" -> setReminder(a)
            "list_items" -> listItems(a.getString("kind"))
            else -> fail("Unknown action: $name")
        }
    } catch (e: Exception) {
        fail(e.message ?: e.javaClass.simpleName)
    }

    // ---------- helpers ----------
    private fun start(i: Intent): Boolean = try {
        ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); true
    } catch (e: ActivityNotFoundException) { false } catch (e: SecurityException) { false }

    private fun launcherApps(): List<Pair<String, String>> {
        val pm = ctx.packageManager
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(i, 0).map { it.loadLabel(pm).toString() to it.activityInfo.packageName }
    }

    private fun findApp(vararg names: String): Pair<String, String>? {
        val apps = launcherApps()
        for (n in names.filter { it.isNotBlank() }) {
            val q = n.trim().lowercase()
            apps.firstOrNull { it.first.lowercase() == q }?.let { return it }
            apps.firstOrNull { it.first.lowercase().contains(q) }?.let { return it }
            apps.firstOrNull { it.first.length > 2 && q.contains(it.first.lowercase()) }?.let { return it }
        }
        return null
    }

    // ---------- apps & media ----------
    private fun openApp(a: JSONObject): JSONObject {
        val n = a.getString("app_name")
        val app = findApp(n, a.optString("alt_name")) ?: return fail("App not found: $n")
        val i = ctx.packageManager.getLaunchIntentForPackage(app.second) ?: return fail("Cannot launch ${app.first}")
        return if (start(i)) ok("Opened ${app.first}") else fail("Could not open ${app.first}")
    }

    private fun searchYoutube(q: String): JSONObject {
        val yt = Intent(Intent.ACTION_SEARCH).setPackage("com.google.android.youtube").putExtra("query", q)
        if (start(yt)) return ok("YouTube search opened for \"$q\"")
        val web = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(q)))
        return if (start(web)) ok("YouTube search opened in browser for \"$q\"") else fail("Could not open YouTube")
    }

    private fun searchTiktok(q: String, kind: String): JSONObject {
        val base = if (kind == "creators") "https://www.tiktok.com/search/user?q=" else "https://www.tiktok.com/search?q="
        val uri = Uri.parse(base + Uri.encode(q))
        for (pkg in listOf("com.zhiliaoapp.musically", "com.ss.android.ugc.trill")) {
            if (start(Intent(Intent.ACTION_VIEW, uri).setPackage(pkg))) return ok("TikTok $kind search opened for \"$q\"")
        }
        return if (start(Intent(Intent.ACTION_VIEW, uri))) ok("TikTok search opened in browser for \"$q\"") else fail("Could not open TikTok")
    }

    private fun openSettings(page: String): JSONObject {
        val action = when (page) {
            "wifi" -> Settings.ACTION_WIFI_SETTINGS
            "bluetooth" -> Settings.ACTION_BLUETOOTH_SETTINGS
            "display" -> Settings.ACTION_DISPLAY_SETTINGS
            "sound" -> Settings.ACTION_SOUND_SETTINGS
            "battery" -> Settings.ACTION_BATTERY_SAVER_SETTINGS
            "apps" -> Settings.ACTION_APPLICATION_SETTINGS
            "location" -> Settings.ACTION_LOCATION_SOURCE_SETTINGS
            "accessibility" -> Settings.ACTION_ACCESSIBILITY_SETTINGS
            "language" -> Settings.ACTION_LOCALE_SETTINGS
            "storage" -> Settings.ACTION_INTERNAL_STORAGE_SETTINGS
            "date" -> Settings.ACTION_DATE_SETTINGS
            else -> Settings.ACTION_SETTINGS
        }
        return if (start(Intent(action))) ok("Opened $page settings") else fail("Could not open $page settings")
    }

    // ---------- accessibility actions ----------
    private fun navigate(action: String): JSONObject {
        val s = FriendAccessibilityService.instance ?: return noService()
        val done = when (action) {
            "scroll_down" -> s.scroll(true)
            "scroll_up" -> s.scroll(false)
            else -> s.global(action)
        }
        return if (done) ok("Done: $action") else fail("Could not perform $action")
    }

    private val sensitiveWords = listOf(
        "send", "pay", "buy", "purchase", "order", "delete", "remove", "transfer", "confirm", "submit",
        "sign out", "log out", "পাঠা", "কিন", "ডিলিট", "মুছ", "পেমেন্ট", "অর্ডার", "ট্রান্সফার"
    )

    private suspend fun tapText(t: String, c: Confirmer): JSONObject {
        val s = FriendAccessibilityService.instance ?: return noService()
        val low = t.lowercase()
        if (sensitiveWords.any { low.contains(it) }) {
            val q = if (bn) "\"$t\" ট্যাপ করবো?" else "Tap \"$t\"?"
            if (!c.confirm(q)) return fail("User declined")
        }
        return if (s.clickByText(t)) ok("Tapped \"$t\"") else fail("No tappable element named \"$t\" found on screen")
    }

    private fun typeText(t: String): JSONObject {
        val s = FriendAccessibilityService.instance ?: return noService()
        return if (s.typeText(t)) ok("Typed text") else fail("No editable field found (or it is a password field)")
    }

    private fun readScreen(): JSONObject {
        val s = FriendAccessibilityService.instance ?: return noService()
        return ok(s.screenSummary())
    }

    // ---------- calls ----------
    private data class Contact(val name: String, val number: String)

    private fun findContacts(q: String): List<Contact> {
        val out = mutableListOf<Contact>()
        ctx.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME, ContactsContract.CommonDataKinds.Phone.NUMBER),
            "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?", arrayOf("%$q%"), null
        )?.use { c -> while (c.moveToNext()) out += Contact(c.getString(0) ?: "", c.getString(1) ?: "") }
        return out
    }

    private suspend fun callContact(a: JSONObject, c: Confirmer): JSONObject {
        if (ctx.checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED)
            return fail("Contacts permission not granted. Ask the user to allow it in Friend AI > Settings.")
        val q = a.getString("name")
        val alt = a.optString("alt_name")
        val matches = listOf(q, alt).filter { it.isNotBlank() }.flatMap { findContacts(it) }
            .distinctBy { it.number.filter(Char::isDigit) }
        if (matches.isEmpty()) return fail("No contact found matching \"$q\"")
        val byName = matches.groupBy { it.name }
        var chosen = byName.keys.first()
        if (byName.size > 1) {
            val exact = byName.keys.filter { it.equals(q, true) || it.equals(alt, true) }
            if (exact.size == 1) chosen = exact[0]
            else return JSONObject().put("ok", false).put("needs_choice", true)
                .put("candidates", JSONArray(byName.keys.take(5)))
                .put("error", "Several contacts match. Ask the user which one they mean.")
        }
        val number = byName.getValue(chosen).first().number
        val prompt = if (bn) "$chosen ($number) কে কল করবো?" else "Call $chosen ($number)?"
        if (!c.confirm(prompt)) return fail("User cancelled the call")
        val granted = ctx.checkSelfPermission(Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED
        start(Intent(if (granted) Intent.ACTION_CALL else Intent.ACTION_DIAL, Uri.fromParts("tel", number, null)))
        return ok("Calling $chosen")
    }

    // ---------- personal ----------
    private suspend fun addNote(a: JSONObject): JSONObject {
        val body = a.getString("body")
        db.notes().insert(Note(title = a.optString("title").ifBlank { body.take(30) }, body = body))
        return ok("Note saved")
    }

    private suspend fun addTodo(text: String): JSONObject { db.todos().insert(Todo(text = text)); return ok("Added to to-do list") }

    private suspend fun completeTodo(text: String): JSONObject {
        val t = db.todos().findOpen(text) ?: return fail("No open to-do matches \"$text\"")
        db.todos().setDone(t.id, true)
        return ok("Marked done: ${t.text}")
    }

    private suspend fun setReminder(a: JSONObject): JSONObject {
        val text = a.getString("text")
        val at: Long = if (a.has("minutes_from_now"))
            System.currentTimeMillis() + (a.getDouble("minutes_from_now") * 60_000).toLong()
        else SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).parse(a.getString("datetime"))!!.time
        if (at <= System.currentTimeMillis()) return fail("That time is in the past")
        val id = db.reminders().insert(Reminder(text = text, triggerAt = at))
        ReminderScheduler.schedule(ctx, Reminder(id, text, at))
        return ok("Reminder set for " + SimpleDateFormat("EEE d MMM, h:mm a", Locale.getDefault()).format(Date(at)))
    }

    private suspend fun listItems(kind: String): JSONObject {
        val arr = JSONArray()
        when (kind) {
            "notes" -> db.notes().recent(20).forEach { arr.put("${it.title}: ${it.body}") }
            "todos" -> db.todos().openItems(30).forEach { arr.put(it.text) }
            else -> db.reminders().pending(System.currentTimeMillis()).forEach {
                arr.put(it.text + " @ " + SimpleDateFormat("d MMM h:mm a", Locale.getDefault()).format(Date(it.triggerAt)))
            }
        }
        return JSONObject().put("ok", true).put("items", arr)
    }
}
