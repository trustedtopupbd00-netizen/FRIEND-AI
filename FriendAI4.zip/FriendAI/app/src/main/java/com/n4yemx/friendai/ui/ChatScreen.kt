package com.n4yemx.friendai.ui

import android.Manifest
import android.content.pm.PackageManager
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.GraphicEq
import androidx.compose.material.icons.rounded.Send
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.n4yemx.friendai.MainViewModel
import com.n4yemx.friendai.R
import com.n4yemx.friendai.data.ChatMessage
import com.n4yemx.friendai.voice.VoiceState

@Composable
fun ChatScreen(vm: MainViewModel) {
    val ctx = LocalContext.current
    val messages by vm.messages.collectAsStateWithLifecycle()
    val busy by vm.busy.collectAsStateWithLifecycle()
    val vstate by vm.voice.state.collectAsStateWithLifecycle()
    val level by vm.voice.level.collectAsStateWithLifecycle()
    val partial by vm.voice.partial.collectAsStateWithLifecycle()
    val pending by vm.pending.collectAsStateWithLifecycle()
    val lang by vm.language.collectAsStateWithLifecycle()
    val hands by vm.handsFree.collectAsStateWithLifecycle()
    val error by vm.error.collectAsStateWithLifecycle()
    var input by remember { mutableStateOf("") }
    val listState = rememberLazyListState()

    val micPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) vm.toggleListening()
    }
    fun onMic() {
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) vm.toggleListening()
        else micPerm.launch(Manifest.permission.RECORD_AUDIO)
    }

    LaunchedEffect(messages.size) { if (messages.isNotEmpty()) listState.animateScrollToItem(messages.lastIndex) }
    LaunchedEffect(error) { error?.let { Toast.makeText(ctx, it, Toast.LENGTH_SHORT).show(); vm.error.value = null } }

    Column(
        Modifier.fillMaxSize()
            .background(Brush.verticalGradient(listOf(Navy, Color(0xFF0A1030))))
            .statusBarsPadding().imePadding()
    ) {
        // header
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Image(painterResource(R.drawable.friend_ai_logo), null, Modifier.size(38.dp).clip(RoundedCornerShape(10.dp)), contentScale = ContentScale.Crop)
            Spacer(Modifier.width(10.dp))
            Text("Friend AI", style = MaterialTheme.typography.titleLarge.copy(brush = NeonBrush, fontWeight = FontWeight.Bold))
            Spacer(Modifier.weight(1f))
            AssistChip(
                onClick = { vm.setLanguage(if (lang.startsWith("bn")) "en-US" else "bn-BD") },
                label = { Text(if (lang.startsWith("bn")) "বাংলা" else "English") },
                colors = AssistChipDefaults.assistChipColors(labelColor = Cyan),
                border = BorderStroke(1.dp, Cyan.copy(alpha = 0.5f))
            )
            Spacer(Modifier.width(4.dp))
            FilledIconToggleButton(
                checked = hands, onCheckedChange = { vm.setHandsFree(it) },
                colors = IconButtonDefaults.filledIconToggleButtonColors(
                    containerColor = PanelHi, contentColor = Color(0xFF9AA6D6),
                    checkedContainerColor = Violet, checkedContentColor = Color.White
                )
            ) { Icon(Icons.Rounded.GraphicEq, contentDescription = "Continuous conversation") }
        }

        Box(Modifier.weight(1f).fillMaxWidth()) {
            if (messages.isEmpty()) Welcome(onPick = { vm.send(it) })
            else LazyColumn(state = listState, contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(messages, key = { it.id }) { Bubble(it) }
            }
        }

        if (vstate == VoiceState.LISTENING && partial.isNotBlank()) {
            Text(partial, Modifier.fillMaxWidth().padding(horizontal = 24.dp), color = Cyan, textAlign = TextAlign.Center, fontSize = 15.sp)
        }

        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = input, onValueChange = { input = it }, modifier = Modifier.weight(1f),
                placeholder = { Text("Type or tap the mic…") }, maxLines = 3,
                shape = RoundedCornerShape(24.dp),
                colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Cyan, unfocusedBorderColor = PanelHi, focusedContainerColor = Panel, unfocusedContainerColor = Panel)
            )
            IconButton(
                onClick = { vm.send(input); input = "" }, enabled = input.isNotBlank() && !busy,
                modifier = Modifier.padding(start = 6.dp).clip(CircleShape).background(if (input.isNotBlank()) Cyan else PanelHi)
            ) { Icon(Icons.Rounded.Send, "Send", tint = Navy) }
        }

        Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
            VoiceOrb(state = vstate, busy = busy, level = level, onClick = { onMic() })
            Text(
                when {
                    busy -> "Thinking…"
                    vstate == VoiceState.LISTENING -> "Listening…"
                    vstate == VoiceState.SPEAKING -> "Speaking… tap to stop"
                    else -> "Tap to talk"
                },
                color = Color(0xFF9AA6D6), fontSize = 12.sp, modifier = Modifier.padding(bottom = 8.dp)
            )
        }
    }

    pending?.let { p ->
        AlertDialog(
            onDismissRequest = { vm.resolvePending(false) },
            containerColor = Panel,
            title = { Text("Please confirm") },
            text = { Text(p.prompt) },
            confirmButton = { Button(onClick = { vm.resolvePending(true) }) { Text("Yes") } },
            dismissButton = { TextButton(onClick = { vm.resolvePending(false) }) { Text("Cancel") } }
        )
    }
}

@Composable
private fun Bubble(m: ChatMessage) {
    val mine = m.role == "user"
    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (mine) Arrangement.End else Arrangement.Start) {
        val shape = RoundedCornerShape(18.dp, 18.dp, if (mine) 4.dp else 18.dp, if (mine) 18.dp else 4.dp)
        Box(
            Modifier.widthIn(max = 300.dp).clip(shape)
                .background(if (mine) Brush.linearGradient(listOf(Blue, Violet)) else Brush.linearGradient(listOf(PanelHi, PanelHi)))
                .padding(horizontal = 14.dp, vertical = 10.dp)
        ) { Text(m.text, color = Color.White, fontSize = 16.sp) }
    }
}

@Composable
private fun Welcome(onPick: (String) -> Unit) {
    Column(Modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Image(painterResource(R.drawable.friend_ai_logo), null, Modifier.size(150.dp).clip(RoundedCornerShape(28.dp)))
        Spacer(Modifier.height(16.dp))
        Text("Hi! I'm your Friend AI", style = MaterialTheme.typography.titleMedium, color = Color.White)
        Text("বাংলা বা English — যেভাবে খুশি বলুন", color = Color(0xFF9AA6D6), fontSize = 14.sp)
        Spacer(Modifier.height(16.dp))
        listOf("Search YouTube for lo-fi music", "ইউটিউবে নতুন গান সার্চ করো", "Remind me in 10 minutes to drink water", "Add milk to my to-do list").forEach {
            SuggestionChip(onClick = { onPick(it) }, label = { Text(it) }, modifier = Modifier.padding(vertical = 2.dp),
                colors = SuggestionChipDefaults.suggestionChipColors(labelColor = Cyan),
                border = BorderStroke(1.dp, Cyan.copy(alpha = 0.4f)))
        }
    }
}
