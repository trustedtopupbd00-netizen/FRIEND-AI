package com.n4yemx.friendai.ui

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.unit.dp
import com.n4yemx.friendai.voice.VoiceState

@Composable
fun VoiceOrb(state: VoiceState, busy: Boolean, level: Float, onClick: () -> Unit) {
    val inf = rememberInfiniteTransition(label = "orb")
    val p by inf.animateFloat(0f, 1f, infiniteRepeatable(tween(1600, easing = LinearEasing)), label = "pulse")
    val spin by inf.animateFloat(0f, 360f, infiniteRepeatable(tween(2200, easing = LinearEasing)), label = "spin")
    val lv by animateFloatAsState(level, label = "level")
    val active = state != VoiceState.IDLE

    Box(Modifier.size(132.dp), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val c = center
            val base = size.minDimension * 0.30f
            if (active) {
                val ring = if (state == VoiceState.LISTENING) Cyan else Violet
                for (i in 0..2) {
                    val f = (p + i / 3f) % 1f
                    drawCircle(
                        color = ring.copy(alpha = (1f - f) * 0.45f),
                        radius = base * (1f + f * 0.9f + lv * 0.25f),
                        center = c, style = Stroke(3f)
                    )
                }
            }
            drawCircle(
                brush = Brush.radialGradient(listOf(Cyan.copy(alpha = 0.35f), Color.Transparent), c, base * 1.9f),
                radius = base * 1.9f, center = c
            )
            drawCircle(brush = NeonBrush, radius = base * (1f + lv * 0.12f), center = c)
            if (busy) {
                rotate(spin, c) {
                    drawArc(
                        color = Color.White, startAngle = 0f, sweepAngle = 100f, useCenter = false,
                        topLeft = Offset(c.x - base * 1.15f, c.y - base * 1.15f),
                        size = Size(base * 2.3f, base * 2.3f),
                        style = Stroke(5f, cap = StrokeCap.Round)
                    )
                }
            }
        }
        IconButton(onClick = onClick, modifier = Modifier.size(80.dp)) {
            Icon(
                if (state == VoiceState.IDLE) Icons.Rounded.Mic else Icons.Rounded.Stop,
                contentDescription = "Voice", tint = Navy, modifier = Modifier.size(34.dp)
            )
        }
    }
}
