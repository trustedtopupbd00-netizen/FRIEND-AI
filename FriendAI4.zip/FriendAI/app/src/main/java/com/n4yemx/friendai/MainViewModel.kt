package com.n4yemx.friendai

import android.app.Application
import android.speech.SpeechRecognizer
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.n4yemx.friendai.ai.ActionEngine
import com.n4yemx.friendai.ai.Confirmer
import com.n4yemx.friendai.ai.GeminiClient
import com.n4yemx.friendai.data.*
import com.n4yemx.friendai.service.ReminderScheduler
import com.n4yemx.friendai.voice.VoiceManager
import com.n4yemx.friendai.voice.VoiceState
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

data class PendingConfirm(val prompt: String, val result: CompletableDeferred<Boolean>)

class MainViewModel(app: Application) : AndroidViewModel(app), Confirmer {
    private val ctx = app.applicationContext
    private val db = AppDatabase.get(ctx)
    private val gemini = GeminiClient()
    private val engine = ActionEngine(ctx, db)
    val voice = VoiceManager(ctx)

    val messages = db.messages().all().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val notes = db.notes().all().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val todos = db.todos().all().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val reminders = db.reminders().all().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val busy = MutableStateFlow(false)
    val pending = MutableStateFlow<PendingConfirm?>(null)
    val error = MutableStateFlow<String?>(null)
    val language = MutableStateFlow(Prefs.language(ctx))
    val speakTyped = MutableStateFlow(Prefs.speakTyped(ctx))
    val handsFree = MutableStateFlow(Prefs.handsFree(ctx))

    private var lastInputVoice = false
    private var silentRounds = 0

    init {
        voice.recognitionTag = language.value
        voice.onFinal = { silentRounds = 0; send(it, fromVoice = true) }
        voice.onError = { code ->
            if (code == SpeechRecognizer.ERROR_NO_MATCH || code == SpeechRecognizer.ERROR_SPEECH_TIMEOUT) {
                silentRounds++
                if (handsFree.value && silentRounds < 2 && !busy.value && pending.value == null) voice.startListening()
                else silentRounds = 0
            } else {
                silentRounds = 0
                error.value = describe(code)
            }
        }
        voice.onSpeakDone = {
            if (lastInputVoice && (pending.value != null || handsFree.value)) voice.startListening()
        }
    }

    private fun describe(code: Int) = when (code) {
        -1 -> "No speech recognition service found. Install/enable the Google app."
        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Microphone permission needed."
        SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "Speech recognition needs internet."
        SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "Recognizer busy, try again."
        else -> "Speech error ($code)."
    }

    // ---------- voice controls ----------
    fun toggleListening() {
        when (voice.state.value) {
            VoiceState.LISTENING -> voice.stopListening()
            VoiceState.SPEAKING -> voice.stopSpeaking()
            VoiceState.IDLE -> { silentRounds = 0; voice.startListening() }
        }
    }

    fun setLanguage(tag: String) { language.value = tag; voice.recognitionTag = tag; Prefs.setLanguage(ctx, tag) }
    fun setSpeakTyped(v: Boolean) { speakTyped.value = v; Prefs.setSpeakTyped(ctx, v) }
    fun setHandsFree(v: Boolean) { handsFree.value = v; Prefs.setHandsFree(ctx, v) }

    // ---------- confirmation (calls, risky taps) ----------
    override suspend fun confirm(prompt: String): Boolean {
        val d = CompletableDeferred<Boolean>()
        pending.value = PendingConfirm(prompt, d)
        if (lastInputVoice) voice.speak(prompt)
        return try { d.await() } finally { pending.value = null }
    }

    fun resolvePending(ok: Boolean) {
        voice.stopListening(); voice.stopSpeaking()
        pending.value?.result?.complete(ok)
    }

    private val yes = listOf("yes", "yeah", "yep", "ok", "okay", "sure", "confirm", "go ahead", "do it", "হ্যাঁ", "হ্যা", "হাঁ", "জি", "ঠিক আছে", "ওকে", "করো")
    private val no = listOf("no", "not", "cancel", "stop", "don't", "না", "থামো", "বাতিল")

    private fun isYes(t: String): Boolean {
        val s = t.lowercase()
        val words = s.split(Regex("[\\s,.!?।]+"))
        if (no.any { if (it.length <= 3) it in words else s.contains(it) }) return false
        return yes.any { if (it.length <= 3) it in words else s.contains(it) }
    }

    // ---------- conversation ----------
    fun send(text: String, fromVoice: Boolean = false) {
        val t = text.trim()
        if (t.isEmpty()) return
        lastInputVoice = fromVoice
        pending.value?.let { it.result.complete(isYes(t)); return }   // answer to a confirmation
        if (busy.value) return
        viewModelScope.launch {
            busy.value = true
            try {
                db.messages().insert(ChatMessage(role = "user", text = t))
                val reply = converse()
                db.messages().insert(ChatMessage(role = "model", text = reply))
                if (fromVoice || speakTyped.value) voice.speak(reply)
            } catch (e: Exception) {
                val m = e.message ?: "Something went wrong"
                db.messages().insert(ChatMessage(role = "model", text = "⚠️ $m"))
                error.value = m
            } finally {
                busy.value = false
            }
        }
    }

    private fun content(role: String, text: String) =
        JSONObject().put("role", role).put("parts", JSONArray().put(JSONObject().put("text", text)))

    private suspend fun converse(): String {
        val history = db.messages().last(24).reversed()
            .filter { !it.text.startsWith("⚠️") }
            .dropWhile { it.role != "user" }
        val contents = JSONArray()
        history.forEach { contents.put(content(it.role, it.text)) }
        val system = systemPrompt()

        repeat(6) {
            val resp = gemini.generate(contents, system)
            val cand = resp.optJSONArray("candidates")?.optJSONObject(0) ?: error("Empty response from Gemini")
            val c = cand.optJSONObject("content") ?: error("Gemini returned no content (${cand.optString("finishReason")})")
            val parts = c.optJSONArray("parts") ?: JSONArray()
            val list = (0 until parts.length()).map { parts.getJSONObject(it) }
            val calls = list.filter { it.has("functionCall") }
            if (calls.isEmpty()) {
                return list.filter { it.has("text") && !it.optBoolean("thought") }
                    .joinToString("") { it.getString("text") }.trim().ifEmpty { "Done." }
            }
            contents.put(JSONObject().put("role", "model").put("parts", parts))
            val responses = JSONArray()
            for (p in calls) {
                val fc = p.getJSONObject("functionCall")
                val name = fc.getString("name")
                val result = engine.execute(name, fc.optJSONObject("args") ?: JSONObject(), this)
                responses.put(
                    JSONObject().put(
                        "functionResponse",
                        JSONObject().put("name", name).put("response", JSONObject().put("result", result))
                    )
                )
            }
            contents.put(JSONObject().put("role", "user").put("parts", responses))
        }
        return "I couldn't finish that request. Please try again."
    }

    private suspend fun systemPrompt(): String {
        val now = SimpleDateFormat("EEEE, yyyy-MM-dd HH:mm", Locale.US).format(Date())
        val tz = TimeZone.getDefault().id
        val notesCtx = db.notes().recent(8).joinToString("; ") { it.title }.ifEmpty { "none" }
        val todoCtx = db.todos().openItems(8).joinToString("; ") { it.text }.ifEmpty { "none" }
        return """
You are Friend AI, a warm, concise personal assistant living on the user's Android phone. Built by N4YEMx.
Current local time: $now ($tz). Speech-recognition language is set to ${language.value}.

Language: reply in the language the user used. If they write or speak Bangla, answer in natural Bangla (Bangla script); if English, answer in English. Mixed input: follow the dominant language.
Style: replies are often read aloud, so keep them short (1-3 sentences), no markdown, no emoji spam.

Actions: use the provided functions to act on the phone. Only say an action succeeded if the function result has ok=true; otherwise explain the problem plainly (e.g. permission or accessibility service missing).
- Calls: always use call_contact. The app asks the user to confirm; never claim a call started unless ok=true. Contact names may be saved in English while speech is transcribed in Bangla (or vice versa): pass name and alt_name (the other script).
- For on-screen tasks: call read_screen to see what is visible, then tap_text / type_text / phone_navigate. Do one step at a time and verify.
- Never type into or read password fields, never enter payment details, never send messages or pay without the user explicitly asking and confirming.
- Relative reminder requests ("in 10 minutes") -> minutes_from_now; absolute times -> datetime in local time.
- If a request is ambiguous (several contacts, unclear app), ask one short question instead of guessing.

User's saved notes (titles): $notesCtx
User's open to-dos: $todoCtx
""".trimIndent()
    }

    // ---------- personal data (UI) ----------
    fun addNote(title: String, body: String) = viewModelScope.launch {
        db.notes().insert(Note(title = title.ifBlank { body.take(30) }, body = body))
    }
    fun deleteNote(id: Long) = viewModelScope.launch { db.notes().deleteById(id) }

    fun addTodo(text: String) = viewModelScope.launch { db.todos().insert(Todo(text = text)) }
    fun toggleTodo(t: Todo) = viewModelScope.launch { db.todos().setDone(t.id, !t.done) }
    fun deleteTodo(id: Long) = viewModelScope.launch { db.todos().deleteById(id) }

    fun addReminder(text: String, minutes: Long) = viewModelScope.launch {
        val at = System.currentTimeMillis() + minutes * 60_000
        val id = db.reminders().insert(Reminder(text = text, triggerAt = at))
        ReminderScheduler.schedule(ctx, Reminder(id, text, at))
    }
    fun deleteReminder(r: Reminder) = viewModelScope.launch {
        ReminderScheduler.cancel(ctx, r.id); db.reminders().deleteById(r.id)
    }

    fun clearChat() = viewModelScope.launch { db.messages().clear() }

    override fun onCleared() { voice.release(); super.onCleared() }
}
