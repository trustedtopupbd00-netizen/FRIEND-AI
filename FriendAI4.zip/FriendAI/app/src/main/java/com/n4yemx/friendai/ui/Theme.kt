package com.n4yemx.friendai.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

val Cyan = Color(0xFF22D3EE)
val Blue = Color(0xFF3B82F6)
val Violet = Color(0xFF8B5CF6)
val Navy = Color(0xFF050816)
val Panel = Color(0xFF0C1230)
val PanelHi = Color(0xFF141B45)

val NeonBrush = Brush.linearGradient(listOf(Cyan, Blue, Violet))

private val scheme = darkColorScheme(
    primary = Cyan, secondary = Violet, tertiary = Blue,
    background = Navy, surface = Panel, surfaceVariant = PanelHi,
    onPrimary = Navy, onSecondary = Color.White, onBackground = Color(0xFFE8ECFF),
    onSurface = Color(0xFFE8ECFF), onSurfaceVariant = Color(0xFF9AA6D6),
    error = Color(0xFFFF6B8A)
)

@Composable
fun FriendTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = scheme, typography = Typography(), content = content)
}
