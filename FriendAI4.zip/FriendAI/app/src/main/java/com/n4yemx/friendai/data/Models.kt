package com.n4yemx.friendai.data

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "messages")
data class ChatMessage(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val role: String,            // "user" | "model"
    val text: String,
    val ts: Long = System.currentTimeMillis()
)

@Entity(tableName = "notes")
data class Note(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val body: String,
    val ts: Long = System.currentTimeMillis()
)

@Entity(tableName = "todos")
data class Todo(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val text: String,
    val done: Boolean = false,
    val ts: Long = System.currentTimeMillis()
)

@Entity(tableName = "reminders")
data class Reminder(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val text: String,
    val triggerAt: Long,
    val fired: Boolean = false
)

@Dao
interface MessageDao {
    @Query("SELECT * FROM messages ORDER BY id ASC") fun all(): Flow<List<ChatMessage>>
    @Query("SELECT * FROM messages ORDER BY id DESC LIMIT :n") suspend fun last(n: Int): List<ChatMessage>
    @Insert suspend fun insert(m: ChatMessage): Long
    @Query("DELETE FROM messages") suspend fun clear()
}

@Dao
interface NoteDao {
    @Query("SELECT * FROM notes ORDER BY id DESC") fun all(): Flow<List<Note>>
    @Query("SELECT * FROM notes ORDER BY id DESC LIMIT :n") suspend fun recent(n: Int): List<Note>
    @Insert suspend fun insert(n: Note): Long
    @Query("DELETE FROM notes WHERE id = :id") suspend fun deleteById(id: Long)
}

@Dao
interface TodoDao {
    @Query("SELECT * FROM todos ORDER BY done ASC, id DESC") fun all(): Flow<List<Todo>>
    @Query("SELECT * FROM todos WHERE done = 0 ORDER BY id DESC LIMIT :n") suspend fun openItems(n: Int): List<Todo>
    @Query("SELECT * FROM todos WHERE done = 0 AND text LIKE '%' || :q || '%' LIMIT 1") suspend fun findOpen(q: String): Todo?
    @Insert suspend fun insert(t: Todo): Long
    @Query("UPDATE todos SET done = :done WHERE id = :id") suspend fun setDone(id: Long, done: Boolean)
    @Query("DELETE FROM todos WHERE id = :id") suspend fun deleteById(id: Long)
}

@Dao
interface ReminderDao {
    @Query("SELECT * FROM reminders ORDER BY triggerAt ASC") fun all(): Flow<List<Reminder>>
    @Query("SELECT * FROM reminders WHERE fired = 0 AND triggerAt > :now") suspend fun pending(now: Long): List<Reminder>
    @Query("SELECT * FROM reminders ORDER BY triggerAt ASC") suspend fun list(): List<Reminder>
    @Insert suspend fun insert(r: Reminder): Long
    @Query("DELETE FROM reminders WHERE id = :id") suspend fun deleteById(id: Long)
    @Query("UPDATE reminders SET fired = 1 WHERE id = :id") suspend fun markFired(id: Long)
}

@Database(
    entities = [ChatMessage::class, Note::class, Todo::class, Reminder::class],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun messages(): MessageDao
    abstract fun notes(): NoteDao
    abstract fun todos(): TodoDao
    abstract fun reminders(): ReminderDao

    companion object {
        @Volatile private var instance: AppDatabase? = null
        fun get(context: Context): AppDatabase = instance ?: synchronized(this) {
            instance ?: Room.databaseBuilder(
                context.applicationContext, AppDatabase::class.java, "friend_ai.db"
            ).build().also { instance = it }
        }
    }
}
