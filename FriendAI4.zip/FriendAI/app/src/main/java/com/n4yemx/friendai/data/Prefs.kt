package com.n4yemx.friendai.data

import android.content.Context

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("friend_ai", Context.MODE_PRIVATE)

    fun language(c: Context): String = sp(c).getString("lang", "bn-BD") ?: "bn-BD"
    fun setLanguage(c: Context, v: String) = sp(c).edit().putString("lang", v).apply()

    fun speakTyped(c: Context): Boolean = sp(c).getBoolean("speak_typed", true)
    fun setSpeakTyped(c: Context, v: Boolean) = sp(c).edit().putBoolean("speak_typed", v).apply()

    fun handsFree(c: Context): Boolean = sp(c).getBoolean("hands_free", false)
    fun setHandsFree(c: Context, v: Boolean) = sp(c).edit().putBoolean("hands_free", v).apply()
}
