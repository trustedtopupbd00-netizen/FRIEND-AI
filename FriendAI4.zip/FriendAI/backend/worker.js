// Cloudflare Worker: keeps your Gemini API key OFF the phone.
// The app sends Gemini generateContent JSON here; this adds the key and forwards it.
export default {
  async fetch(req, env) {
    if (req.method !== "POST") return new Response("Method not allowed", { status: 405 });
    if (req.headers.get("X-App-Token") !== env.APP_TOKEN) return new Response("Unauthorized", { status: 401 });

    const body = await req.text();
    if (body.length > 200_000) return new Response("Request too large", { status: 413 });

    const model = env.GEMINI_MODEL || "gemini-2.5-flash";
    const upstream = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent`,
      {
        method: "POST",
        headers: { "Content-Type": "application/json", "x-goog-api-key": env.GEMINI_API_KEY },
        body,
      }
    );
    return new Response(upstream.body, {
      status: upstream.status,
      headers: { "Content-Type": "application/json" },
    });
  },
};
